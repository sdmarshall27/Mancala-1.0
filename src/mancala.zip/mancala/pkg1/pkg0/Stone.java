
package mancala.pkg1.pkg0;

public class Stone {
    
}
